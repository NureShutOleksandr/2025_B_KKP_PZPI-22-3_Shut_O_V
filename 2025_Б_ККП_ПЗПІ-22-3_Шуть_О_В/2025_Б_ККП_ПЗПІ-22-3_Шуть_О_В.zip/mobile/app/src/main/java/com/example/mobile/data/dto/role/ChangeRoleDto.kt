package com.example.mobile.data.dto.role

data class ChangeRoleDto(
    val userId: String,
    val roleId: String
)
